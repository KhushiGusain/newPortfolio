(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_page_tsx_b025fed5._.js",
  "static/chunks/node_modules_next_0766a282._.js"
],
    source: "dynamic"
});
