(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__81f21d00._.css",
  "static/chunks/_ffcc8f47._.js"
],
    source: "dynamic"
});
